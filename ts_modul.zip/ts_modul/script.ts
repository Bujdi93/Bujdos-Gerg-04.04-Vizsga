function PhErtek(vizsgaltErtek: number): string {
 
    if (vizsgaltErtek < 7) {
      return "savas";
    } else if (vizsgaltErtek > 7) {
      return "lugos";
    } else {
      return "semleges";
    }
  }

  function PrimekSzama(vizsgaltTomb: number[]): number {


    let primekSzama = 0;
    for (const szam of vizsgaltTomb) {
      if (isPrime(szam)) {
        primekSzama++;
      }
    }
  
    return primekSzama;
  }
  
  function isPrime(szam: number): boolean {
    if (szam <= 1) {
      return false;
    }
    for (let i = 2; i <= Math.sqrt(szam); i++) {
      if (szam % i === 0) {
        return false;
      }
    }
    return true;
  }

  function MaganHangzokSzama(vizsgaltSzoveg: string): number {
  
    const kisbetusSzoveg = vizsgaltSzoveg.toLowerCase();
    const maganhangzok = "aáeéiíoóöőuúüű";
  
    let maganhangzokSzama = 0;
    for (const char of kisbetusSzoveg) {
      if (maganhangzok.includes(char)) {
        maganhangzokSzama++;
      }
    }
  
    return maganhangzokSzama;
  }