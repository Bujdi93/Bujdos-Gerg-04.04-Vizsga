function PhErtek(vizsgaltErtek) {
    if (vizsgaltErtek < 7) {
        return "savas";
    }
    else if (vizsgaltErtek > 7) {
        return "lugos";
    }
    else {
        return "semleges";
    }
}
function PrimekSzama(vizsgaltTomb) {
    var primekSzama = 0;
    for (var _i = 0, vizsgaltTomb_1 = vizsgaltTomb; _i < vizsgaltTomb_1.length; _i++) {
        var szam = vizsgaltTomb_1[_i];
        if (isPrime(szam)) {
            primekSzama++;
        }
    }
    return primekSzama;
}
function isPrime(szam) {
    if (szam <= 1) {
        return false;
    }
    for (var i = 2; i <= Math.sqrt(szam); i++) {
        if (szam % i === 0) {
            return false;
        }
    }
    return true;
}
function MaganHangzokSzama(vizsgaltSzoveg) {
    var kisbetusSzoveg = vizsgaltSzoveg.toLowerCase();
    var maganhangzok = "aáeéiíoóöőuúüű";
    var maganhangzokSzama = 0;
    for (var _i = 0, kisbetusSzoveg_1 = kisbetusSzoveg; _i < kisbetusSzoveg_1.length; _i++) {
        var char = kisbetusSzoveg_1[_i];
        if (maganhangzok.includes(char)) {
            maganhangzokSzama++;
        }
    }
    return maganhangzokSzama;
}
