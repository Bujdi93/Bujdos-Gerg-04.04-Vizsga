import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-feladat',
  standalone: true,
  imports: [FormsModule,
  CommonModule],
  templateUrl: './feladat.component.html',
  styleUrl: './feladat.component.css'
})
export class FeladatComponent {

  szam: number = 0
  logok : any [] =[]

  get primszam(): boolean {
    if (this.szam <= 1) {
      return false;
    }
  
    for (let i = 2; i <= Math.sqrt(this.szam); i++) {
      if (this.szam % i === 0) {
        return false;
      }
    }
  
    return true;
  }

  eredmenyMentes(): void {
    
    this.logok.push(this.szam);
  }

}




